#!/usr/bin/env python3
"""Corrige les cours figés de la ligne en dollars de Londres (fonds peu échangés en 2008-2014).
Sur chaque période où la clôture USD reste identique plusieurs séances de suite alors que la ligne en livres
du même fonds cote, le chemin intermédiaire suit la ligne en livres convertie au cours GBP/USD du jour,
recalé géométriquement pour finir exactement sur le prochain cours USD réel. Les cours USD réels ne sont
jamais modifiés ; seules les séances figées sont remplacées. Les fichiers d'origine sont conservés dans data/raw/."""
import pandas as pd, numpy as np, shutil, json, os
D = "../data/"
fx = pd.read_csv(D + "GBPUSD_X.csv", index_col=0, parse_dates=True)["Close"].dropna()
report = {}
for usd, gbx in [("ISDW.L", "ISWD.L"), ("ISDU.L", "ISUS.L")]:
    raw = D + "raw/" + usd + ".csv"
    if not os.path.exists(raw): shutil.copy(D + usd + ".csv", raw)
    df = pd.read_csv(raw, index_col=0, parse_dates=True)
    u = df["Close"].copy(); g = pd.read_csv(D + gbx + ".csv", index_col=0, parse_dates=True)["Close"]
    rec = (g / 100 * fx.reindex(g.index).ffill()).reindex(u.index)
    same = u.diff() == 0
    fixed = 0; runs = 0; i = 1; idx = u.index; periods = []
    while i < len(u):
        if same.iloc[i]:
            a = i - 1; j = i
            while j < len(u) and same.iloc[j]: j += 1
            b = j  # premier cours réel après la période figée (ou fin de série)
            seg = rec.iloc[a:b+1]
            ok = b < len(u) and (b - a) >= 3 and seg.notna().all()
            # garde-fous : pas de rupture d'unité dans la ligne en livres (saut > 15 % en une séance),
            # et un recalage final de moins de 5 % (sinon les deux lignes ne racontent pas la même chose)
            if ok: ok = seg.pct_change().abs().max() < 0.15 and abs((u.iloc[b] / u.iloc[a]) / (rec.iloc[b] / rec.iloc[a]) - 1) < 0.05
            if ok:
                n = b - a; adj = (u.iloc[b] / u.iloc[a]) / (rec.iloc[b] / rec.iloc[a])
                for k in range(1, n):
                    u.iloc[a + k] = u.iloc[a] * rec.iloc[a + k] / rec.iloc[a] * adj ** (k / n)
                fixed += n - 1; runs += 1; periods.append({"du": str(idx[a + 1].date()), "au": str(idx[b - 1].date()), "seances": int(n - 1), "cours_reel_avant": str(idx[a].date()), "cours_reel_apres": str(idx[b].date())})
            i = j
        else: i += 1
    out = df.copy(); out["Close"] = u
    out.to_csv(D + usd + ".csv")
    report[usd] = {"seances_corrigees": int(fixed), "periodes": int(runs), "source_chemin": gbx + " × GBPUSD", "periodes_corrigees": periods, "par_annee": {str(y): int(((df["Close"] != u) & (df.index.year == y)).sum()) for y in range(2008, 2027) if ((df["Close"] != u) & (df.index.year == y)).sum()}}
json.dump(report, open(D + "corrections_cours_figes.json", "w"), ensure_ascii=False, indent=1); print(json.dumps(report, ensure_ascii=False))
