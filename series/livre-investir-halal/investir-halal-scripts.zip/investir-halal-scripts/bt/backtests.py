#!/usr/bin/env python3
"""Backtests du livre — données Yahoo Finance (voir ../data/provenance.json), closes ajustés dividendes.
Toutes les sorties vont dans results.json ; chaque chiffre publié dans le livre doit venir d'ici."""
import pandas as pd, numpy as np, json, math, datetime
D = "../data/"
def load(t):
    fn = t.replace("^", "IDX_").replace("=", "_") + ".csv"
    df = pd.read_csv(D + fn, index_col=0, parse_dates=True)
    return df["Close"].dropna()

R = {"generated_at": datetime.datetime.utcnow().isoformat() + "Z", "source": "Yahoo Finance via yfinance 1.0, auto_adjust=True (closes ajustés des dividendes)", "tests": {}}

def cagr(s):
    yrs = (s.index[-1] - s.index[0]).days / 365.25
    return (s.iloc[-1] / s.iloc[0]) ** (1 / yrs) - 1
def maxdd(s):
    dd = s / s.cummax() - 1
    return dd.min(), dd.idxmin()
def stats(s, label):
    s = s.dropna()
    dd, ddd = maxdd(s)
    # années civiles : la première compte si la série démarre dans les dix premiers jours de janvier ;
    # la dernière est marquée « en cours » si elle s'arrête avant le 20 décembre (exclue des meilleures/pires).
    y_end = s.resample("YE").last(); base = y_end.shift(1); base.iloc[0] = s.iloc[0]
    yearly = (y_end / base - 1).dropna()
    if s.index[0] > pd.Timestamp(s.index[0].year, 1, 10): yearly = yearly.iloc[1:]
    partial = s.index[-1] < pd.Timestamp(s.index[-1].year, 12, 20)
    complete = yearly.iloc[:-1] if partial else yearly
    # recovery time from max DD
    peak_date = s[:ddd].idxmax(); peak_val = s[:ddd].max()
    after = s[ddd:]; rec = after[after >= peak_val]
    rec_days = (rec.index[0] - peak_date).days if len(rec) else None
    vol = s.pct_change().std() * math.sqrt(252)
    return {"label": label, "from": str(s.index[0].date()), "to": str(s.index[-1].date()),
            "years": round((s.index[-1] - s.index[0]).days / 365.25, 2), "total_return_pct": round((s.iloc[-1] / s.iloc[0] - 1) * 100, 1),
            "cagr_pct": round(cagr(s) * 100, 2), "max_dd_pct": round(dd * 100, 1), "max_dd_date": str(ddd.date()),
            "peak_before_dd": str(peak_date.date()), "recovery_days": rec_days, "vol_annual_pct": round(vol * 100, 1),
            "worst_year": {"year": int(complete.idxmin().year), "pct": round(complete.min() * 100, 1)} if len(complete) else None,
            "best_year": {"year": int(complete.idxmax().year), "pct": round(complete.max() * 100, 1)} if len(complete) else None,
            "yearly_pct": {str(k.year): round(v * 100, 1) for k, v in yearly.items()}, "derniere_annee_en_cours": bool(partial),
            "annees_completes": int(len(complete)), "annees_completes_positives": int((complete > 0).sum())}

def align(a, b):
    df = pd.concat([a, b], axis=1, join="inner").dropna(); return df.iloc[:, 0], df.iloc[:, 1]

# ---------- 1. Halal vs conventionnel, même fenêtre ----------
pairs = [("ISDW.L", "IWDA.L", "Monde islamique vs Monde (UCITS, USD)"),
         ("ISDU.L", "CSPX.L", "USA islamique vs S&P 500 (UCITS, USD)"),
         ("ISDE.L", "EEM", "Émergents islamique vs Émergents (USD)"),
         ("SPUS", "SPY", "S&P 500 Sharia (SP Funds) vs S&P 500 (US)"),
         ("HLAL", "SPY", "FTSE USA Shariah (Wahed) vs S&P 500 (US)"),
         ("ISDW.L", "URTH", "Monde islamique vs MSCI World (iShares US)")]
R["tests"]["halal_vs_conventionnel"] = []
for h, c, lab in pairs:
    a, b = align(load(h), load(c))
    R["tests"]["halal_vs_conventionnel"].append({"pair": lab, "halal": stats(a, h), "conv": stats(b, c),
        "corr_daily": round(a.pct_change().corr(b.pct_change()), 3)})

# ---------- 2. Séries longues seules ----------
R["tests"]["series_longues"] = {t: stats(load(t), t) for t in ["ISDW.L", "ISDU.L", "ISDE.L", "SPY", "^GSPC", "QQQ", "^IXIC", "GC=F", "SPSK", "VWCE.DE"]}
# Nasdaq 2000 : chute et temps de récupération
ix = load("^IXIC"); top = ix["1999":"2000"].idxmax(); bot = ix[top:"2003"].idxmin(); rec = ix[bot:][ix[bot:] >= ix[top]].index[0]
R["tests"]["nasdaq_2000"] = {"top": str(top.date()), "top_val": round(ix[top], 1), "bottom": str(bot.date()), "bottom_val": round(ix[bot], 1),
    "drawdown_pct": round((ix[bot] / ix[top] - 1) * 100, 1), "recovered_on": str(rec.date()), "years_to_recover": round((rec - top).days / 365.25, 1)}
sp = load("^GSPC"); top = sp["2007"].idxmax(); bot = sp[top:"2009-12"].idxmin(); rec = sp[bot:][sp[bot:] >= sp[top]].index[0]
R["tests"]["sp500_2008_prix"] = {"top": str(top.date()), "bottom": str(bot.date()), "drawdown_pct": round((sp[bot] / sp[top] - 1) * 100, 1), "recovered_on": str(rec.date()), "years_to_recover": round((rec - top).days / 365.25, 1), "note": "indice prix, hors dividendes"}

# ---------- 3. Investisseur en euros : ISDW converti ----------
eur = load("EURUSD=X"); w = load("ISDW.L"); w_eur = (w / eur.reindex(w.index).ffill()).dropna()
R["tests"]["isdw_en_euros"] = {"usd": stats(w, "ISDW.L USD"), "eur": stats(w_eur, "ISDW.L converti EUR"), "note": "même fonds, valeur convertie au cours EUR/USD du jour"}

# ---------- 4. DCA vs lump sum vs 'attendre la baisse' ----------
def dca(s, monthly=200.0, start=None):
    s = s if start is None else s[start:]
    m = s.resample("MS").first().dropna()
    units = (monthly / m).cumsum(); invested = monthly * np.arange(1, len(m) + 1)
    value = units * m
    return pd.DataFrame({"value": value, "invested": invested})
def xirr(cash, dates, final, final_date):
    # taux annuel tel que somme(cf/(1+r)^t) = 0
    t = np.array([(d - dates[0]).days / 365.25 for d in dates]); tf = (final_date - dates[0]).days / 365.25
    f = lambda r: np.sum(-cash / (1 + r) ** t) + final / (1 + r) ** tf
    lo, hi = -0.9, 1.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if f(mid) > 0: lo = mid
        else: hi = mid
    return mid
w = load("ISDW.L")
d = dca(w); m = w.resample("MS").first().dropna()
R["tests"]["dca_isdw_2008"] = {"monthly_eur": 200, "months": len(d), "invested": round(d.invested.iloc[-1]), "final_value": round(d.value.iloc[-1]),
    "multiple": round(d.value.iloc[-1] / d.invested.iloc[-1], 2), "irr_pct": round(xirr(np.full(len(m), 200.0), list(m.index), d.value.iloc[-1], m.index[-1]) * 100, 2),
    "min_value_vs_invested_pct": round(((d.value / d.invested).min() - 1) * 100, 1), "min_date": str((d.value / d.invested).idxmin().date()),
    "months_underwater": int(((d.value / d.invested) < 1).sum())}
# attendre une baisse de 10 % avant chaque versement (cash dort sinon)
def wait_for_dip(s, monthly=200.0, dip=0.10):
    # le signal (baisse de dip sous le plus haut des 252 dernières séances) est constaté à la clôture,
    # l'achat se fait à la clôture suivante
    cash = 0.0; units = 0.0; invested = 0.0; hist = []; pending = False
    months = s.resample("MS").first().dropna().index
    hi = s.rolling(252, min_periods=1).max()
    next_m = 0
    for dt, px in s.items():
        if pending and cash > 0: units += cash / px; cash = 0.0
        pending = False
        if next_m < len(months) and dt >= months[next_m]:
            cash += monthly; invested += monthly; next_m += 1
        if px <= hi[dt] * (1 - dip) and cash > 0: pending = True
        hist.append((dt, units * px + cash, invested))
    h = pd.DataFrame(hist, columns=["d", "value", "invested"]).set_index("d")
    return h
for dip in (0.05, 0.10, 0.20):
    h = wait_for_dip(w, dip=dip)
    R["tests"][f"attendre_baisse_{int(dip*100)}pct"] = {"final_value": round(h.value.iloc[-1]), "invested": round(h.invested.iloc[-1]), "multiple": round(h.value.iloc[-1] / h.invested.iloc[-1], 2), "vs_dca_pct": round((h.value.iloc[-1] / d.value.iloc[-1] - 1) * 100, 1)}
# lump sum au pire moment (01/2008) vs DCA sur 24 mois
ls = w.iloc[-1] / w.iloc[0]
R["tests"]["lump_sum_2008_vs_dca"] = {"lump_sum_multiple_since_2008": round(ls, 2), "lump_sum_cagr_pct": round(cagr(w) * 100, 2), "note": "versement unique le 2 janvier 2008, juste avant la crise"}

# ---------- 5. Rater les meilleurs jours / pires jours ----------
def miss_days(s, n, best=True):
    r = s.pct_change().dropna(); idx = r.nlargest(n).index if best else r.nsmallest(n).index
    r2 = r.drop(idx); return (1 + r2).prod() - 1
for t in ["ISDW.L", "^GSPC"]:
    s = load(t); s = s["1996":] if t == "^GSPC" else s
    base = s.iloc[-1] / s.iloc[0] - 1
    R["tests"][f"rater_jours_{t}"] = {"from": str(s.index[0].date()), "to": str(s.index[-1].date()), "buy_hold_total_pct": round(base * 100, 1),
        "miss_best_10_pct": round(miss_days(s, 10) * 100, 1), "miss_best_20_pct": round(miss_days(s, 20) * 100, 1), "miss_best_40_pct": round(miss_days(s, 40) * 100, 1),
        "miss_worst_10_pct": round(miss_days(s, 10, best=False) * 100, 1), "miss_both_10_pct": round(((1 + s.pct_change().dropna().drop(s.pct_change().dropna().nlargest(10).index).drop(s.pct_change().dropna().nsmallest(10).index)).prod() - 1) * 100, 1),
        "best_days_in_bear_pct": None}
    r = s.pct_change().dropna(); best = r.nlargest(20).index; dd = s / s.cummax() - 1
    R["tests"][f"rater_jours_{t}"]["best_20_days_while_in_drawdown_over_10pct"] = int((dd.reindex(best) < -0.10).sum())

# ---------- 6. Timing moyenne mobile (200 jours / 10 mois) ----------
def sma_timing(s, n=200, cost=0.001, monthly=False):
    # signal constaté à la clôture (quotidienne, ou de fin de mois pour la règle des 10 mois),
    # position prise à la clôture de la séance suivante : shift(2) sur les rendements clôture à clôture
    if monthly:
        m = s.resample("ME").last(); sm = (m > m.rolling(10).mean())
        raw = sm.reindex(s.index, method="ffill").fillna(False)
    else:
        raw = (s > s.rolling(n).mean())
    sig = raw.shift(2).fillna(False).astype(bool); r = s.pct_change().fillna(0)
    trades = int((sig != sig.shift(1)).iloc[1:].sum())
    strat = (1 + r * sig).cumprod() * (1 - cost) ** ((sig != sig.shift(1)).cumsum())
    bh = (1 + r).cumprod()
    return {"strategy": stats(strat, f"SMA{n if not monthly else '10m'}"), "buy_hold": stats(bh, "achat-conservation"), "trades": trades, "allers_retours": trades // 2, "time_in_market_pct": round(sig.mean() * 100, 1), "cost_per_switch_pct": cost * 100}
R["tests"]["sma200_isdw"] = sma_timing(load("ISDW.L"))
R["tests"]["sma10m_isdw"] = sma_timing(load("ISDW.L"), monthly=True)
R["tests"]["sma200_sp500_1990"] = sma_timing(load("^GSPC")["1990":])
R["tests"]["sma10m_sp500_1990"] = sma_timing(load("^GSPC")["1990":], monthly=True)
R["tests"]["sma200_sp500_1950"] = sma_timing(load("^GSPC")["1950":])

# ---------- 7. Stop-loss sur un ETF ----------
def trailing_stop(s, stop=0.10, reentry="new_high", cost=0.001):
    # déclenchement constaté à la clôture, ordre exécuté à la clôture suivante
    inv = True; peak = s.iloc[0]; eq = 1.0; hist = []; trades = 0; exit_px = None; go_out = go_in = False
    prev = s.iloc[0]
    for dt, px in s.items():
        if inv: eq *= px / prev
        if go_out: inv = False; trades += 1; eq *= (1 - cost); exit_px = px; go_out = False
        elif go_in: inv = True; eq *= (1 - cost); peak = px; go_in = False
        elif inv:
            peak = max(peak, px)
            if px <= peak * (1 - stop): go_out = True; peak_exit = peak
        else:
            if (reentry == "new_high" and px >= peak_exit) or (reentry == "plus5" and px >= exit_px * 1.05): go_in = True
        prev = px; hist.append((dt, eq))
    h = pd.Series(dict(hist))
    return {"strategy": stats(h, f"stop {int(stop*100)}% réentrée {reentry}"), "trades": trades}
w = load("ISDW.L")
R["tests"]["stop_loss_isdw"] = {"buy_hold": stats(w / w.iloc[0], "achat-conservation"),
    "stop10_newhigh": trailing_stop(w, 0.10, "new_high"), "stop10_plus5": trailing_stop(w, 0.10, "plus5"), "stop20_newhigh": trailing_stop(w, 0.20, "new_high"), "stop20_plus5": trailing_stop(w, 0.20, "plus5")}

# ---------- 8. Panique : vendre à -20 %, racheter après +20 % ----------
def panic(s, out=0.20, back=0.20, cost=0.001):
    inv = True; peak = s.iloc[0]; trough = None; eq = 1.0; prev = s.iloc[0]; hist = []; n = 0; go_out = go_in = False
    for dt, px in s.items():
        if inv: eq *= px / prev
        if go_out: inv = False; trough = px; n += 1; eq *= 1 - cost; go_out = False
        elif go_in: inv = True; peak = px; eq *= 1 - cost; go_in = False
        elif inv:
            peak = max(peak, px)
            if px <= peak * (1 - out): go_out = True
        else:
            trough = min(trough, px)
            if px >= trough * (1 + back): go_in = True
        prev = px; hist.append((dt, eq))
    return {"strategy": stats(pd.Series(dict(hist)), "panique -20/+20"), "exits": n}
R["tests"]["panique_isdw"] = panic(load("ISDW.L")); R["tests"]["panique_sp500_1990"] = panic(load("^GSPC")["1990":])

# ---------- 9. Horizons : probabilité de perte selon la durée ----------
def horizon_table(s, label):
    out = {}
    for yrs in (1, 3, 5, 10, 15):
        n = yrs * 252
        if len(s) <= n + 10: continue
        rr = (s.shift(-n) / s - 1).dropna(); ann = (1 + rr) ** (1 / yrs) - 1
        out[f"{yrs}y"] = {"windows": int(len(rr)), "prob_loss_pct": round((rr < 0).mean() * 100, 1), "worst_total_pct": round(rr.min() * 100, 1), "best_total_pct": round(rr.max() * 100, 1),
                          "median_annualized_pct": round(ann.median() * 100, 2), "p10_annualized_pct": round(ann.quantile(0.1) * 100, 2), "p90_annualized_pct": round(ann.quantile(0.9) * 100, 2)}
    return {"label": label, "from": str(s.index[0].date()), "to": str(s.index[-1].date()), "horizons": out}
R["tests"]["horizons_isdw"] = horizon_table(load("ISDW.L"), "MSCI World Islamic UCITS (USD)")
R["tests"]["horizons_sp500_1950"] = horizon_table(load("^GSPC")["1950":], "S&P 500 prix depuis 1950 (hors dividendes)")
R["tests"]["horizons_spy"] = horizon_table(load("SPY"), "SPY total return depuis 1993")

# ---------- 10. Or comme coussin : 70/30 rééquilibré chaque année ----------
g = load("GC=F"); w = load("ISDW.L"); a, b = align(w, g)
def rebalanced(a, b, wa, freq="YE", cost=0.001):
    ra = a.pct_change().fillna(0); rb = b.pct_change().fillna(0)
    eq = 1.0; va = wa; vb = 1 - wa; hist = []; reb_dates = set(a.resample(freq).last().index)
    for dt in a.index:
        va *= 1 + ra[dt]; vb *= 1 + rb[dt]
        if dt in reb_dates:
            tot = va + vb; turn = abs(va - tot * wa); va = tot * wa; vb = tot * (1 - wa); va -= turn * cost
        hist.append((dt, va + vb))
    return pd.Series(dict(hist))
R["tests"]["or_coussin"] = {"100_actions": stats(a / a.iloc[0], "100 % ISDW"), "100_or": stats(b / b.iloc[0], "100 % or"),
    "80_20": stats(rebalanced(a, b, 0.8), "80/20 rééquilibré annuel"), "70_30": stats(rebalanced(a, b, 0.7), "70/30 rééquilibré annuel"), "60_40": stats(rebalanced(a, b, 0.6), "60/40 rééquilibré annuel"),
    "corr_daily": round(a.pct_change().corr(b.pct_change()), 3)}
# sukuk comme coussin depuis 2020
s_, w2 = align(load("SPSK"), load("ISDW.L"))
R["tests"]["sukuk_coussin_2020"] = {"100_actions": stats(w2 / w2.iloc[0], "100 % ISDW"), "100_sukuk": stats(s_ / s_.iloc[0], "100 % SPSK"), "70_30": stats(rebalanced(w2, s_, 0.7), "70/30 rééquilibré annuel"), "corr_daily": round(w2.pct_change().corr(s_.pct_change()), 3)}

# ---------- 11. Frais : arithmétique ----------
def fees(r=0.07, yrs=25, monthly=300.0):
    out = {}
    for ter in (0.0, 0.003, 0.006, 0.01, 0.015, 0.02):
        net = (1 + r) * (1 - ter) - 1; m = (1 + net) ** (1 / 12) - 1
        fv = monthly * (((1 + m) ** (yrs * 12) - 1) / m)
        out[f"{ter*100:.1f}%"] = round(fv)
    return out
R["tests"]["frais_25_ans_300_par_mois_7pct"] = fees()
R["tests"]["frais_25_ans_300_par_mois_5pct"] = fees(r=0.05)

# ---------- 12. Concentration : une action vs l'indice (dispersion) ----------
# (pas de données par action ici ; laissé aux sources citées)

# ---------- 13. Zakat : exemple ----------
gold_last = float(load("GC=F").iloc[-1]); eur_last = float(load("EURUSD=X").iloc[-1])
nisab_usd = gold_last / 31.1035 * 85
R["tests"]["zakat_nisab"] = {"gold_usd_per_oz": round(gold_last, 2), "eurusd": round(eur_last, 4), "nisab_85g_usd": round(nisab_usd), "nisab_85g_eur": round(nisab_usd / eur_last), "as_of": str(load("GC=F").index[-1].date())}
silver_last = float(load("SI=F").iloc[-1])
R["tests"]["zakat_nisab"].update({"silver_usd_per_oz": round(silver_last, 2), "nisab_595g_argent_eur": round(silver_last / 31.1035 * 595 / eur_last), "as_of_argent": str(load("SI=F").index[-1].date())})

# ---------- 14. Volatilité : amplitude typique ----------
w = load("ISDW.L"); r = w.pct_change().dropna()
R["tests"]["amplitude_isdw"] = {"jours_sous_-2pct": int((r < -0.02).sum()), "jours_total": int(len(r)), "pire_jour_pct": round(r.min() * 100, 2), "pire_jour": str(r.idxmin().date()), "meilleur_jour_pct": round(r.max() * 100, 2), "meilleur_jour": str(r.idxmax().date()),
    "annees_avec_baisse_10pct_intra": int(sum(1 for y, grp in w.groupby(w.index.year) if (grp / grp.cummax() - 1).min() <= -0.10)), "annees_total": int(w.index.year.nunique()),
    "annees_positives": stats(w, "x")["annees_completes_positives"], "annees_comptees": stats(w, "x")["annees_completes"]}

# ---------- 15. Épisodes de recul : 2008, 2020, 2022 ----------
def episode(s, start, end):
    seg = s[start:end]; top = seg.idxmax(); bot = s[top:end].idxmin(); after = s[bot:]; rec = after[after >= s[top]]
    return {"top": str(top.date()), "bottom": str(bot.date()), "drawdown_pct": round((s[bot] / s[top] - 1) * 100, 1), "days_to_bottom": (bot - top).days,
            "recovered_on": str(rec.index[0].date()) if len(rec) else None, "days_to_recover": (rec.index[0] - top).days if len(rec) else None}
w = load("ISDW.L")
R["tests"]["episodes_isdw"] = {"2008": episode(w, "2008-01-01", "2009-06-30"), "2020": episode(w, "2020-01-01", "2020-04-30"), "2022": episode(w, "2021-10-01", "2022-12-31")}
# ---------- 16. Fausses alertes de la moyenne 10 mois ----------
m = w.resample("ME").last(); sig = (m > m.rolling(10).mean()).shift(1).fillna(False).astype(bool)
exits = []; px_exit = None
for i in range(1, len(sig)):
    if sig.iloc[i - 1] and not sig.iloc[i]: px_exit = m.iloc[i]
    if (not sig.iloc[i - 1]) and sig.iloc[i] and px_exit is not None: exits.append(m.iloc[i] > px_exit); px_exit = None
R["tests"]["sma10m_fausses_alertes"] = {"sorties": len(exits), "rachats_plus_haut": int(sum(exits)), "part_pct": round(100 * sum(exits) / max(1, len(exits)), 0)}
# ---------- 17. Ce que coûte l'écart halal/conventionnel sur une vie d'épargne ----------
gap = R["tests"]["halal_vs_conventionnel"][0]["conv"]["cagr_pct"] - R["tests"]["halal_vs_conventionnel"][0]["halal"]["cagr_pct"]
def fv(r, yrs=25, monthly=300.0):
    mm = (1 + r) ** (1 / 12) - 1; return monthly * (((1 + mm) ** (yrs * 12) - 1) / mm)
R["tests"]["ecart_halal_sur_25_ans"] = {"gap_pts": round(gap, 2), "fv_7pct": round(fv(0.07)), "fv_7pct_moins_gap": round(fv(0.07 - gap / 100)), "difference_eur": round(fv(0.07) - fv(0.07 - gap / 100))}
# ---------- 18. Bitcoin ----------
b = load("BTC-USD"); st = stats(b, "BTC-USD")
def ep(s, a, z):
    seg = s[a:z]; top = seg.idxmax(); bot = s[top:z].idxmin(); after = s[bot:]; rec = after[after >= s[top]]
    return {"top": str(top.date()), "bottom": str(bot.date()), "drawdown_pct": round((s[bot] / s[top] - 1) * 100, 1),
            "recovered_on": str(rec.index[0].date()) if len(rec) else None, "days_to_recover": (rec.index[0] - top).days if len(rec) else None}
yb = st["yearly_pct"]
R["tests"]["bitcoin"] = {"from": st["from"], "to": st["to"], "cagr_pct": round(st["cagr_pct"], 1), "max_dd_pct": st["max_dd_pct"], "max_dd_date": st["max_dd_date"], "vol_annual_pct": round(float(b.pct_change().std()) * math.sqrt(365) * 100, 1),
    "episodes": {"2017-2018": ep(b, "2017-01-01", "2018-12-31"), "2021-2022": ep(b, "2021-01-01", "2022-12-31")},
    "yearly_pct": {k: round(v) for k, v in yb.items()}, "annees_negatives": int(sum(1 for v in yb.values() if v < 0)), "annees": len(yb), "last_price": round(float(b.iloc[-1]))}
# ---------- 19. « Vendez en mai » ----------
def sell_in_may(s):
    m = s.resample("ME").last(); r = m.pct_change().dropna(); summer = r.index.month.isin([5, 6, 7, 8, 9, 10])
    ann = lambda x: (np.prod(1 + x)) ** (12 / len(x)) - 1
    yrs = sorted(set(r.index.year)); ete = [np.prod(1 + r[(r.index.year == y) & summer]) - 1 for y in yrs if ((r.index.year == y) & summer).sum() == 6]
    strat = (1 + r.where(~summer, 0)).cumprod(); bh = (1 + r).cumprod()
    n = len(r) / 12
    return {"mai_oct_annualise_pct": round(ann(r[summer]) * 100, 2), "nov_avr_annualise_pct": round(ann(r[~summer]) * 100, 2), "mois_mai_oct": int(summer.sum()), "mois_nov_avr": int((~summer).sum()),
            "part_annees_ete_positif_pct": round(100 * np.mean([e > 0 for e in ete])), "strategie_nov_avr_cagr_pct": round((strat.iloc[-1] ** (1 / n) - 1) * 100, 2), "achat_conservation_cagr_pct": round((bh.iloc[-1] ** (1 / n) - 1) * 100, 2)}
R["tests"]["sell_in_may_isdw"] = sell_in_may(load("ISDW.L")); R["tests"]["sell_in_may_sp500_1950"] = sell_in_may(load("^GSPC")["1950":])
# ---------- 20. Vérification des chiffres des séries du site ----------
def tr(t, a, z):
    s = load(t)[a:z]; return [round((s.iloc[-1] / s.iloc[0] - 1) * 100, 1), str(s.index[0].date()), str(s.index[-1].date())]
R["tests"]["verif_series_perf"] = {"isdw_2010_2020": tr("ISDW.L", "2010-01-01", "2020-12-31"), "iwda_2010_2020": tr("IWDA.L", "2010-01-01", "2020-12-31"), "spy_2010_2020": tr("SPY", "2010-01-01", "2020-12-31"),
    "isdw_2008": tr("ISDW.L", "2008-01-01", "2008-12-31"), "spy_2008": tr("SPY", "2008-01-01", "2008-12-31"), "isdw_2022": tr("ISDW.L", "2022-01-01", "2022-12-31"), "iwda_2022": tr("IWDA.L", "2022-01-01", "2022-12-31"), "spy_2022": tr("SPY", "2022-01-01", "2022-12-31"),
    "isdw_2020_2026_cagr_pct": round(cagr(load("ISDW.L")["2020-01-02":]) * 100, 2), "iwda_2020_2026_cagr_pct": round(cagr(load("IWDA.L")["2020-01-02":]) * 100, 2),
    "note": "vérification des affirmations des séries « La Bourse pour le musulman » et « Comprendre le marché »"}
# ---------- 21. Projections et temps contre montant ----------
F = fees(); F5 = fees(r=0.05); F9 = fees(r=0.09)
R["tests"]["projection_300_par_mois_25_ans"] = {"verse": 90000, "5pct": F5["0.3%"], "7pct": F["0.3%"], "9pct": F9["0.3%"], "ter": 0.3, "note": "brut avant impôts, frais du fonds 0,30 % déduits"}
R["tests"]["temps_vs_montant"] = {"500_sur_30_ans_7pct": round(fv(0.07, 30, 500)), "1000_sur_20_ans_7pct": round(fv(0.07, 20, 1000)), "verse_500x30": 180000, "verse_1000x20": 240000,
    "mensualite_pour_500k_a_65_ans_7pct": {f"depart_{a}_ans": round(500000 / fv(0.07, 65 - a, 1)) for a in (25, 35, 45, 55)}}
# ---------- 22. VIX : acheter le S&P 500 après un pic de peur (achat à la clôture du lendemain) ----------
vix = load("^VIX"); spy = load("SPY"); vv = vix.reindex(spy.index).ffill()
def vix_episodes(th, gap=20):
    out = []; idx = spy.index
    for i in range(gap, len(idx) - 253):
        if vv.iloc[i] > th and (vv.iloc[i - gap:i] <= th).all():
            b = i + 1; p0 = spy.iloc[b]
            out.append([str(idx[i].date()), round(float(vv.iloc[i]), 1), round((spy.iloc[b + 126] / p0 - 1) * 100, 1), round((spy.iloc[b + 252] / p0 - 1) * 100, 1)])
    m6 = [e[2] for e in out]; m12 = [e[3] for e in out]
    return {"seuil": th, "episodes": len(out), "liste": out, "mediane_6m_pct": round(float(np.median(m6)), 1), "mediane_12m_pct": round(float(np.median(m12)), 1),
            "part_positive_12m_pct": round(100 * np.mean([x > 0 for x in m12])), "pire_12m_pct": min(m12), "execution": "achat à la clôture de la séance qui suit le franchissement"}
R["tests"]["vix_30"] = vix_episodes(30); R["tests"]["vix_40"] = vix_episodes(40)
f12 = (spy.shift(-252) / spy - 1).dropna()
R["tests"]["spy_12m_toutes_dates"] = {"mediane_pct": round(float(f12.median()) * 100, 1), "part_positive_pct": round(float((f12 > 0).mean()) * 100)}
# ---------- 23. Mars 2020, pics du VIX, incident du 21 juin 2026 ----------
spx = load("^GSPC"); gc = load("GC=F"); sk = load("SPSK"); btc = load("BTC-USD")
p = spx["2020-01-01":"2020-04-30"]; pk = p["2020-02-01":"2020-02-29"].idxmax(); tr = p.idxmin()
g = gc[pk:tr]; s = sk[pk:"2020-03-31"]
R["tests"]["crise_mars_2020"] = {"sp500_sommet": str(pk.date()), "sp500_creux": str(tr.date()), "sp500_baisse_pct": round((p[tr] / p[pk] - 1) * 100, 1),
    "or_plus_bas_pct": round((g.min() / g.iloc[0] - 1) * 100, 1), "or_plus_bas_date": str(g.idxmin().date()),
    "or_annee_2020_pct": round((gc["2020"].iloc[-1] / gc["2019"].iloc[-1] - 1) * 100, 1),
    "sukuk_spsk_plus_bas_pct": round((s.min() / s.iloc[0] - 1) * 100, 1), "sukuk_spsk_plus_bas_date": str(s.idxmin().date()),
    "bitcoin_12_mars_pct": round((btc["2020-03-12"] / btc["2020-03-11"] - 1) * 100, 1)}
R["tests"]["vix_pics"] = {y: {"date": str(vix[y].idxmax().date()), "valeur": round(float(vix[y].max()), 2)} for y in ("2008", "2020")}
inc = pd.read_csv(D + "INCIDENT_20260621_closes.csv", index_col=0, parse_dates=True)
def ytd(c):
    x = inc[c].dropna(); b = x[:"2025-12-31"]; e = x[:"2026-06-20"]
    return {"base": str(b.index[-1].date()), "fin": str(e.index[-1].date()), "ytd_pct": round((e.iloc[-1] / b.iloc[-1] - 1) * 100, 1), "cloture": round(float(e.iloc[-1]), 2)}
_prov = json.load(open(D + "provenance.json"))["series"]
R["tests"]["corrections"] = {k: {"seances": v["correction"]["seances_corrigees"], "annee_2009": v["correction"]["par_annee"].get("2009", 0), "methode": v["correction"]["methode"]} for k, v in _prov.items() if "correction" in v}
R["tests"]["incident_20260621"] = {c.replace("^", ""): ytd(c) for c in inc.columns}
json.dump(R, open("results.json", "w"), indent=1, ensure_ascii=False, default=str)
print("ok", len(R["tests"]), "tests")
