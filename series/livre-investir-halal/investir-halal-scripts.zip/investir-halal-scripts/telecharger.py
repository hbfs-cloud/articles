#!/usr/bin/env python3
"""Télécharge les cours utilisés par le livre « Investir halal, sans se raconter d'histoires » (édition d'octobre 2026).
Source : Yahoo Finance, par la bibliothèque yfinance. C'est un outil non officiel : usage personnel et ponctuel seulement.
Les cours ajustés des dividendes sont recalculés par Yahoo à chaque nouveau versement : vos résultats différeront
légèrement de ceux du livre (fichier bt/results.json), sans changer les conclusions."""
import os, glob, yfinance as yf, pandas as pd
D = "data/"; os.makedirs(D + "raw", exist_ok=True)
FIN = "2026-10-11"  # lendemain de l'extraction du livre (10 octobre 2026) ; mettez une date plus récente pour actualiser
SERIES = ["ISDW.L", "ISWD.L", "IWDA.L", "URTH", "SPUS", "HLAL", "UMMA", "SPY", "QQQ", "ISUS.L", "ISDU.L", "ISDE.L", "EEM",
          "^GSPC", "^IXIC", "^VIX", "GC=F", "SI=F", "EURUSD=X", "GBPUSD=X", "VWCE.DE", "CSPX.L", "SPSK", "BTC-USD", "ETH-USD"]
def plat(df):
    if isinstance(df.columns, pd.MultiIndex): df.columns = df.columns.get_level_values(0)
    return df
for t in SERIES:
    df = plat(yf.download(t, start="1900-01-01", end=FIN, auto_adjust=True, progress=False))
    df.to_csv(D + t.replace("^", "IDX_").replace("=", "_") + ".csv"); print(t, len(df), "séances")
# vérification de l'incident du chapitre 15 : clôtures non ajustées
inc = ["META", "XOM", "DAL", "MRVL", "XLE", "^RUT", "^N225"]
yf.download(inc, start="2025-12-20", end="2026-06-23", auto_adjust=False, progress=False)["Close"].to_csv(D + "INCIDENT_20260621_closes.csv")
# les copies brutes servent à la réparation des cours figés : on repart des fichiers qui viennent d'être téléchargés
for f in glob.glob(D + "raw/*.csv"): os.remove(f)
print("Ensuite : cd bt && python3 fix_stale.py && python3 backtests.py")
